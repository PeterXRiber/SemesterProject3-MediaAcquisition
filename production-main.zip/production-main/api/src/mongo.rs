use mongodb::{Client, results::InsertOneResult};
use mongodb::bson::{doc};
use crate::dataclasses::{Track, Artist, Album};


async fn get_client() -> mongodb::error::Result<Client> {
    let client = Client::with_uri_str("mongodb://mongo:27017").await?;

    // Ping the server to ensure that we are connected.
    client
    .database("admin")
    .run_command(doc!{ "ping": 1 }, None)
    .await?;

    Ok(client)
}

pub async fn insert_track(track: &Track) -> mongodb::error::Result<InsertOneResult> {
    let client = get_client().await?;

	client
        .database("metadata")
        .collection::<Track>("tracks")
        .insert_one(track, None)
        .await
}

pub async fn insert_artist(artist: &Artist) -> mongodb::error::Result<InsertOneResult> {
    let client = get_client().await?;

    client
        .database("metadata")
        .collection::<Artist>("artists")
        .insert_one(artist, None)
        .await
}

pub async fn insert_album(album: &Album) -> mongodb::error::Result<InsertOneResult> {
    let client = get_client().await?;

    client
        .database("metadata")
        .collection::<Album>("albums")
        .insert_one(album, None)
        .await
}

pub async fn album_exists(album_id: &String) -> bool {
    let client = get_client().await.unwrap();

    client
    .database("metadata")
    .collection::<Album>("albums")
    .find_one(
        doc! {
                "id": album_id
        },
        None,
    )
    .await
    .unwrap()
    .is_some()
}

pub async fn artist_exists(artist_id: &String) -> bool {
    let client = get_client().await.unwrap();

    client
    .database("metadata")
    .collection::<Artist>("artists")
    .find_one(
        doc! {
                "id": artist_id
        },
        None,
    )
    .await
    .unwrap()
    .is_some()
}