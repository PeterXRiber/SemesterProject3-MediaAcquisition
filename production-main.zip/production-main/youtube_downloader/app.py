from flask import Flask, request, render_template, abort
import yt_dlp
import json
import requests
import base64
import random
import os

# This sets up the application using the Flask object from the package flask.
app = Flask(__name__, template_folder='templates')
app.config['UPLOAD_FOLDER'] = 'uploads'
# Using decorators the route is associated with the following method.

@app.route('/', methods=['GET'])
def index():
	return render_template('index.html')

@app.route("/downloadaudio", methods=['POST'])
def download():
	# Get the URL from the request
	url = request.form['url']
	#checks if the URL points the right way
	if not checkURL(url):
		return abort(403,"invalid URL, it has to start with either https://music.youtube.com/ or https://www.youtube.com/")
	# download the audio from the url and save the filename
	ydl_opts = {
		'format': 'bestaudio/best',
		'outtmpl': '%(id)s.wav',
		'nocheckcertificate': True,
		'postprocessors': [{
			'key': 'FFmpegExtractAudio',
			'preferredcodec': 'wav',
		}],
		'ffmpeg_location': 'youtube_downloader/ffmpeg'
	}

	with yt_dlp.YoutubeDL(ydl_opts) as ydl:
		info = ydl.extract_info(url)
		ydl.download([url])
		# Get the filename of the downloaded file
		filename = ydl.prepare_filename(info)
		#get id
		id = filename.replace(".wav", "")

	#sends the file to Media streaming
	response = MediaStreamingPostRequest(filename, id)
	os.remove(filename)

	if response.ok:
		return json.dumps({'success':True}), 200, {'ContentType':'application/json'}
	else:
		return json.dumps({'success':False}), 200, {'ContentType':'application/json'}


@app.route("/metadata", methods=['GET'])
def metadata():
	url = request.args['url']
	#checks if the URL points the right way
	if not checkURL(url):
		return abort(403,"invalid URL, it has to start with either https://music.youtube.com/ or https://www.youtube.com/")

	ydl_opts = { 'noplaylist': True }
	with yt_dlp.YoutubeDL(ydl_opts) as ydl:
		metadata = ydl.extract_info(url, download=False)

	if not metadata:
		return json.dumps({'success':False}), 200, {'ContentType':'application/json'}

	data = {}
	for field in fields_to_extract:
		if field in metadata:
			data[field] = metadata[field]

	if not sendMetadata(data).ok:
		abort(500, 'failed to send metadata to the database')
	
	return data

@app.route("/submit", methods=['POST'])
def upload():
	metadata: dict = json.loads(request.form['metadata'])
	#get the file from the request
	file = request.files['file']
	#create id
	placeholder_id = random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_', k=11)
	id = ''.join(placeholder_id)

	#save the file
	filename = f"fs_{id}.wav"
	file.save(filename)

	#sends the file to Media streaming
	response = MediaStreamingPostRequest(filename, id)
	os.remove(filename)
	
	data = {}
	for field in fields_to_extract:
		if field in metadata:
			data[field] = metadata[field]

	if not sendMetadata(data).ok:
		abort(500, 'failed to send metadata to the database')
	
	if response.ok:
		return json.dumps({'success':True}), 200, {'ContentType':'application/json'}
	else:
		return json.dumps({'success':False}), 200, {'ContentType':'application/json'}


def sendMetadata(data) -> requests.Response:
	url = ''
	response = requests.post(url,json=data)
	return response


#https://www.w3schools.com/python/ref_requests_post.asp
def MediaStreamingPostRequest(file, id):
	url = os.getenv('MEDIA_STREAMING_URL')
	if url is None:
		abort(400,'failed to load env')

	enc = base64.b64encode(open(file, "rb").read())

	body = {
		"id": id,
		"file": enc
	}

	response = requests.post(url, data=body)
	return response

def checkURL(url):
	return url.startswith('https://www.youtube.com/') or url.startswith('https://music.youtube.com/') or url.startswith('https://youtu.be/')

fields_to_extract = [
	"abr",
	"acodec",
	"album",
	"alt_title",
	"artist",
	"asr",
	"audio_channels",
	"channel",
	"creator",
	"duration",
	"id",
	"release_year",
	"tags",
	"title",
	"track",
	"upload_date"
]

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=5050)