pub mod dataclasses;

use std::{error::Error, fmt::Display, env::VarError};
use rocket::futures;
use dataclasses::{Track, Artist};
use serde::{Deserialize, Serialize};
use crate::dataclasses::AudioFeatures;

#[derive(Debug)]
pub enum SearchError {
	InvalidWebserverResponse(reqwest::Error),
	ParsingError(serde_json::Error),
	MissingEnvironmentVariable(VarError)
}

impl From<reqwest::Error> for SearchError {
    fn from(e: reqwest::Error) -> Self {
        Self::InvalidWebserverResponse(e)
    }
}

impl From<serde_json::Error> for SearchError {
    fn from(e: serde_json::Error) -> Self {
        Self::ParsingError(e)
    }
}

impl From<VarError> for SearchError {
    fn from(e: VarError) -> Self {
        Self::MissingEnvironmentVariable(e)
    }
}

impl Display for SearchError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Shit went bad, yo")
    }
}

impl Error for SearchError {}

#[derive(Deserialize, Serialize, Clone)]
pub struct Tracks {
	pub items: Vec<Track>
}

#[derive(Deserialize, Serialize, Clone)]
pub struct SearchResponse {
	pub tracks: Tracks
}

pub async fn search(query_string: &str) -> Result<Vec<Track>, SearchError> {
    let client = reqwest::Client::new();
	let token = get_token().await?;
	let base_url = "https://api.spotify.com/v1";
    let response_text = client.get(base_url.to_owned() + "/search")
		.query(&[
			("q", query_string),
			("type", "track"),
			("market", "DK")
		])
		.header("Authorization", format!("Bearer {}", token))
		.send()
		.await?
		.text()
		.await?;

    let search_results: SearchResponse = serde_json::from_str(response_text.as_str())?;

	let mut tracks = search_results.tracks.items;

	for mut track in &mut tracks {
		track.artists = futures::future::join_all(
		track.artists
			.iter()
			.map(|artist| async {
				get_artist(&artist.id).await
			})
		)
		.await
		.iter()
		.filter_map(|r| {
			match r {
				Ok(artist) => Some(artist.clone()),
				Err(_) => {
					None
				}
			}
		})
		.collect();
	}

	Ok(tracks)
}

pub async fn get_audio_features(track_id: &str) -> Result<AudioFeatures, SearchError> {
	let client = reqwest::Client::new();
	let token = get_token().await?;
	let base_url = "https://api.spotify.com/v1";
	let text_response = client.get(base_url.to_owned() + "/audio-features/" + track_id)
		.header("Authorization", format!("Bearer {}", token))
		.send()
		.await?
		.text()
		.await?;

	let audio_features: AudioFeatures = serde_json::from_str(text_response.as_str())?;

	Ok(audio_features)
}

async fn get_artist(artist_id: &str) -> Result<Artist, SearchError> {
	let client = reqwest::Client::new();
	let token = get_token().await?;
	let base_url = "https://api.spotify.com/v1";
	let text_response = client.get(format!("{}/artists/{}", base_url.to_owned(), artist_id))
		.header("Authorization", format!("Bearer {}", token))
		.send()
		.await?
		.text()
		.await?;

	let artist: Artist = serde_json::from_str(text_response.as_str())?;
	Ok(artist)
}

#[derive(serde::Deserialize)]
struct TokenResponse {
	access_token: String,
}

async fn get_token() -> Result<String, SearchError> {
	let client = reqwest::Client::new();
	let client_id = std::env::var("SPOTIFY_CLIENT_ID")?;
	let client_secret = std::env::var("SPOTIFY_CLIENT_SECRET")?;
	let base64_encoded = base64::encode(format!("{}:{}", client_id, client_secret));
	let text_response = client.post("https://accounts.spotify.com/api/token")
		.header("Authorization", format!("Basic {}", base64_encoded))
		.form(&[("grant_type", "client_credentials")])
		.send()
		.await?
		.text()
		.await?;

	let token_response: TokenResponse = serde_json::from_str(text_response.as_str())?;

	let token = token_response.access_token;

	Ok(token)
}


#[cfg(test)]
mod tests {
	use super::*;
	use tokio;

	#[tokio::test]
	async fn search_does_not_panic() {
		assert!(search("Never gonna give you up").await.is_ok());
	}

	#[tokio::test]
	async fn get_audio_features_does_not_panic() {
		assert!(get_audio_features("bad id").await.is_err());
	}

	#[tokio::test]
	async fn get_token_does_not_panic() {
		assert!(get_token().await.is_ok());
	}

	#[tokio::test]
	async fn get_artist_does_not_panic() {
		assert!(get_artist("bad id").await.is_ok());
	}

	#[tokio::test]
	async fn get_artist_returns_valid_data() {
		let actual_return = get_artist("6eUKZXaKkcviH0Ku9w2n3V").await.unwrap();
		assert!(actual_return.name == "Ed Sheeran");
		let genres = actual_return.genres.unwrap();
		assert!(genres.contains(&"pop".to_owned()));
		assert!(genres.contains(&"uk pop".to_owned()));
	}

	#[tokio::test]
	async fn search_returns_valid_data() {
		search("Bad Habits artist:Ed Sheeran").await.unwrap();
	}
}