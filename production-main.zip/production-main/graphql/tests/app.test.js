const Album = require('../models/album');
const Artist = require('../models/artist');
const { Track, AudioFeatures, PlaybackData } = require('../models/track');

const mongoose = require('mongoose');

const DATABASE_URL="mongodb://localhost:27017/tests";

const connectionString = DATABASE_URL;
mongoose.connect(connectionString);


test('Saving an album to and loading an album from the database', async () => {
    const album = new Album({
        id: '5Z9iiGl2FcIfa3BMiv6OIw',
        name: 'Whenever You Need Somebody',
    });

    await album.save();

    const savedAlbum = await Album.findOne({ name: 'Whenever You Need Somebody' });
    expect(savedAlbum.id).toBe('5Z9iiGl2FcIfa3BMiv6OIw');
    expect(savedAlbum.name).toBe('Whenever You Need Somebody');
});

test('Saving an artist to and loading an artist from the database', async () => {
    const artist = new Artist({
        id: '0gxyHStUsqpMadRV0Di1Qt',
        name: 'Rick Astley',
        genres: [
            "disco",
            "new romantic",
            "new wave pop",
            "soft rock",
            "sophisti-pop",
            "synthpop"
        ],
    });

    await artist.save();

    const savedArtist = await Artist.findOne({name: 'Rick Astley'});
    expect(savedArtist.id).toBe('0gxyHStUsqpMadRV0Di1Qt');
    expect(savedArtist.name).toBe('Rick Astley');
    expect(savedArtist.genres).toStrictEqual([
        "disco",
        "new romantic",
        "new wave pop",
        "soft rock",
        "sophisti-pop",
        "synthpop"
    ]);
});

test('Saving a Track to and loading a Track from the database', async () => {
    const audioFeatures = new AudioFeatures({
		acousticness: 0.115,
		danceability: 0.721,
		duration_ms: 213573,
		energy: 0.939,
		instrumentalness: 0.0000379,
		key: 8,
		liveness: 0.108,
		loudness: -11.823,
		mode: 1,
		speechiness: 0.0376,
		tempo: 113.309,
		time_signature: 4,
		valence: 0.914
    });

    const playbackData = new PlaybackData({
		bit_rate: 129.689,
		sample_rate: 48000,
		codec: "opus",
		audio_channels: 2,
		duration: 212
    });

    const track = new Track({
        id: "yt_dQw4w9WgXcQ",
        name: "Never Gonna Give You Up",
        album_id: "5Z9iiGl2FcIfa3BMiv6OIw",
        artist_ids: [
            "0gxyHStUsqpMadRV0Di1Qt"
        ],
        audio_features: audioFeatures,
        playback_data: playbackData,
    });

    await track.save();

    const savedTrack = await Track.findOne({id: 'yt_dQw4w9WgXcQ'});
    expect(savedTrack.id).toBe('yt_dQw4w9WgXcQ');
    expect(savedTrack.name).toBe('Never Gonna Give You Up');
    expect(savedTrack.album_id).toBe('5Z9iiGl2FcIfa3BMiv6OIw');
    expect(savedTrack.artist_ids).toStrictEqual([
        "0gxyHStUsqpMadRV0Di1Qt"
    ]);

    expect(savedTrack.audio_features.acousticness).toBe(0.115);
    expect(savedTrack.audio_features.danceability).toBe(0.721);
    expect(savedTrack.audio_features.duration_ms).toBe(213573);
    expect(savedTrack.audio_features.energy).toBe(0.939);
    expect(savedTrack.audio_features.instrumentalness).toBe(0.0000379);
    expect(savedTrack.audio_features.key).toBe(8);
    expect(savedTrack.audio_features.liveness).toBe(0.108);
    expect(savedTrack.audio_features.loudness).toBe(-11.823);
    expect(savedTrack.audio_features.mode).toBe(1);
    expect(savedTrack.audio_features.speechiness).toBe(0.0376);
    expect(savedTrack.audio_features.tempo).toBe(113.309);
    expect(savedTrack.audio_features.time_signature).toBe(4);
    expect(savedTrack.audio_features.valence).toBe(0.914);

    expect(savedTrack.playback_data.bit_rate).toBe(129.689);
    expect(savedTrack.playback_data.sample_rate).toBe(48000);
    expect(savedTrack.playback_data.codec).toBe("opus");
    expect(savedTrack.playback_data.audio_channels).toBe(2);
    expect(savedTrack.playback_data.duration).toBe(212);

});

afterAll(async () => {
    //clearing database after tests
    await Album.deleteMany();
    await Artist.deleteMany();
    await Track.deleteMany();

    await mongoose.connection.close();
});

