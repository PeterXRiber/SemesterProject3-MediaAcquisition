import pytest
import os
import app
import json
from unittest import mock
from time import sleep
#https://www.reddit.com/r/youtubedl/comments/qqrbv5/windows_ffmpeg_installed_but_error_postprocessing/

@pytest.fixture()
def client():
    return app.app.test_client()

def test_metadata(client):
    response = client.get("/metadata?url=https://music.youtube.com/watch?v=Rbgw_rduQpM")
    assert response.json == {
	"abr": 135.293,
	"acodec": "opus",
	"album": "Cyberpunk 2077: Radio, Vol. 2 (Original Soundtrack)",
	"alt_title": "I Really Want to Stay at Your House",
	"artist": "Rosa Walton, Hallie Coggins",
	"asr": 48000,
	"audio_channels": 2,
	"channel": "Various Artists - Topic",
	"creator": "Rosa Walton, Hallie Coggins",
	"duration": 247,
	"id": "Rbgw_rduQpM",
	"release_year": 2020,
	"tags": [
		"Rosa Walton Hallie Coggins Cyberpunk 2077: Radio",
		"Vol. 2 (Original Soundtrack) I Really Want to Stay at Your House"
	],
	"title": "I Really Want to Stay at Your House",
	"track": "I Really Want to Stay at Your House",
	"upload_date": "20201217"
    }	

def test_index(client):
	response = client.get("/")
	assert response.status_code == 200

def test_checkURL():
	url = 'https://www.pornhub.com/view_video.php?viewkey=ph635c02bf68735'
	assert app.checkURL(url) == False

#python -m flask --app youtube_downloader/dummyServer run
@mock.patch.dict(os.environ, {"MEDIA_STREAMING_URL": "http://localhost:5000/test"}, clear=True)
def test_downloadaudio(client):
	body = {
		"url": 'https://music.youtube.com/watch?v=Rbgw_rduQpM'
	}

	response = client.post('/downloadaudio', data=body)
	assert response.status_code == 200

@mock.patch.dict(os.environ, {"MEDIA_STREAMING_URL": "http://localhost:5000/test"}, clear=True)
def test_submit(client):
	metadata: dict = {
	"abr": 135.293,
	"acodec": "opus",
	"album": "Cyberpunk 2077: Radio, Vol. 2 (Original Soundtrack)",
	"alt_title": "I Really Want to Stay at Your House",
	"artist": "Rosa Walton, Hallie Coggins",
	"asr": 48000,
	"audio_channels": 2,
	"channel": "Various Artists - Topic",
	"creator": "Rosa Walton, Hallie Coggins",
	"duration": 247,
	"id": "Rbgw_rduQpM",
	"release_year": 2020,
	"tags": [
		"Rosa Walton Hallie Coggins Cyberpunk 2077: Radio",
		"Vol. 2 (Original Soundtrack) I Really Want to Stay at Your House"
	],
	"title": "I Really Want to Stay at Your House",
	"track": "I Really Want to Stay at Your House",
	"upload_date": "20201217"
    }
	
	body = {
		'metadata': json.dumps(metadata),
		'file': open('IReallyWantToStayAtYourHouse.mp3','rb')
	}

	response = client.post('/submit', data=body)

	assert response.status_code == 200

@mock.patch.dict(os.environ, {"MEDIA_STREAMING_URL": "http://localhost:5000/test"}, clear=True)
def test_MediaStreamingPostRequest():

	file = 'IReallyWantToStayAtYourHouse.mp3'
	id ='testId'

	assert app.MediaStreamingPostRequest(file=file,id=id).status_code == 200