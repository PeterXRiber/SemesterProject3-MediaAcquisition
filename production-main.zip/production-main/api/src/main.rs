// #![warn(clippy::pedantic)]
#![warn(clippy::nursery)]
#![warn(clippy::unwrap_used)]
#![warn(clippy::expect_used)]

#[macro_use] extern crate rocket;
use core::panic;
use std::error::Error;
use std::fmt::Display;

use rocket::serde::json::Json;

mod youtube;
mod spotify;
mod mongo;

mod dataclasses;

use dataclasses::{Track, Album, Artist};
use serde::Deserialize;

#[derive(Debug)]
enum Arguments {
    Album,
    Artists,
}

#[derive(Debug)]
enum AcquireError {
    MissingArgument(Arguments),
    AlbumNotFound(String),
    ArtistNotFound(String),
}

impl Display for AcquireError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let message = match self {
            AcquireError::MissingArgument(arg) => match arg {
                Arguments::Album => "Album not supplied",
                Arguments::Artists => "Artists not supplied",
            },
            AcquireError::AlbumNotFound(id) => id,
            AcquireError::ArtistNotFound(id) => id,
        };
        f.write_str(format!("AcquireError: {message}").as_str())
    }
}

impl Error for AcquireError {}

#[get("/")]
fn index() -> &'static str {
    "Hello, world!"
}

#[derive(Deserialize)]
struct AcquireData {
    url: String,
    album_id: Option<String>,
    artist_ids: Option<Vec<String>>,
}

#[post("/acquire", format = "json", data = "<json>")]
async fn acquire(json: Json<AcquireData>) -> String {
    let url = json.url.as_str();
    let youtube_track = youtube::get_metadata(url).await.expect("Failed to get metadata");

    // search for the track on spotify using all available youtube data
    let query_string = youtube::search_params_from_youtube_track(&youtube_track);
    let search_results = spotify::search(&query_string).await.unwrap();
    let spotify_track = if search_results.is_empty() {
        None
    } else {
        // use the first search result
        Some(search_results[0].clone())
    };

    // use the user-specified album id
    // if that wasn't supplied, use the spotify track's album id
    // if the album doesn't exist, create it
    // if the user-specified album id was not supplied and no spotify track was found, exit with an error
    let album_id = match json.album_id.clone() {
        Some(album_id) => {
            if !mongo::album_exists(&album_id).await {
                panic!("invalid album_id")
            }
            album_id
        },
        None => match spotify_track.clone() {
            Some(track) => {
                if !mongo::album_exists(&track.clone().album.id).await {
                    mongo::insert_album(&track.clone().album.into()).await.unwrap();
                }
                track.album.id
            },
            None => {
                panic!("Cannot find spotify track, and artist_ids was not specified.")
            },
        },
    };

    // same as album_id, but for artists
    let artist_ids = match json.artist_ids.clone() {
        Some(artist_ids) => {
            for artist_id in artist_ids.clone() {
                if !mongo::artist_exists(&artist_id).await {
                    panic!("invalid artist_id")
                }
            }

            artist_ids
        },
        None => match spotify_track.clone() {
            Some(track) => {
                for artist in track.artists.clone() {
                    if !mongo::artist_exists(&artist.id).await {
                        mongo::insert_artist(&(&artist).into()).await.unwrap();
                    }
                }
                track.artists
                .iter()
                .map(|artist| {
                    artist.id.clone()
                })
                .collect()
            },
            None => {
                panic!("Cannot find spotify track, and artist_ids was not specified.")
            },
        },
    };

    let track = match spotify_track.clone() {
        None => {
            Track {
                id: "yt_".to_owned() + &youtube_track.id.clone(),
                name: youtube_track.track.clone().or(Some(youtube_track.title.clone())).unwrap(),
                album_id: album_id.clone(),
                artist_ids: artist_ids.clone(),
                playback_data: youtube_track.into(),
                audio_features: None,
            }
        },
        Some(track) => {
            let spotify_track = track;
            let audio_features = spotify::get_audio_features(&spotify_track.id).await.unwrap();
            Track {
                id: "yt_".to_owned() + &youtube_track.id.clone(),
                name: spotify_track.name,
                album_id: spotify_track.album.id,
                artist_ids: spotify_track.artists.iter().map(|artist| artist.id.clone()).collect(),
                playback_data: youtube_track.into(),
                audio_features: Some(audio_features),
            }
        }
    };

    mongo::insert_track(&track).await.expect("Failed to insert metadata");

    serde_json::to_string(&track).expect("Failed to serialize response")
}

#[post("/create_album", format = "json", data = "<album>")]
async fn create_album(album: Json<Album>) -> String {
    mongo::insert_album(&album)
    .await
    .unwrap()
    .inserted_id
    .to_string()
}

#[post("/create_artist", format = "json", data = "<artist>")]
async fn create_artist(artist: Json<Artist>) -> String {
    mongo::insert_artist(&artist)
    .await
    .unwrap()
    .inserted_id
    .to_string()
}

#[launch]
fn rocket() -> _ {
    rocket::build().mount("/", routes![index, acquire, create_album, create_artist])
}