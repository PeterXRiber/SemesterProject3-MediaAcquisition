use serde::{Deserialize, Serialize};

use crate::{youtube, spotify};

#[derive(Deserialize, Serialize, Clone)]
pub struct Artist {
    pub id: String,
    pub name: String,
    pub genres: Vec<String>,
}

impl From<&spotify::dataclasses::Artist> for Artist {
    fn from(spotify_album: &spotify::dataclasses::Artist) -> Self {
		Self {
			id: spotify_album.id.clone(),
			name: spotify_album.name.clone(),
			genres: spotify_album.genres.clone().or(Some(Vec::new())).unwrap(),
		}
    }
}


#[derive(Deserialize, Serialize, Clone)]
pub struct Album {
    pub id: String,
    pub name: String,
}

impl From<spotify::dataclasses::Album> for Album {
    fn from(spotify_album: spotify::dataclasses::Album) -> Self {
		Self {
			id: spotify_album.id,
			name: spotify_album.name,
		}
    }
}


#[derive(Deserialize, Serialize, Clone)]
pub struct AudioFeatures {
    pub acousticness: f32,
    pub danceability: f32,
    pub duration_ms: i32,
    pub energy: f32,
    pub instrumentalness: f32,
    pub key: i32,
    pub liveness: f32,
    pub loudness: f32,
    pub mode: i32,
    pub speechiness: f32,
    pub tempo: f32,
    pub time_signature: i32,
    pub valence: f32,
}

#[derive(Deserialize, Serialize, Clone)]
pub struct PlaybackData {
    pub bit_rate: f32,
    pub sample_rate: u32,
    pub codec: String,
    pub audio_channels: u32,
    pub duration: u32,
}

impl From<youtube::Track> for PlaybackData {
    fn from(yt_track: youtube::Track) -> Self {
        Self {
            bit_rate: yt_track.abr,
            sample_rate: yt_track.asr,
            codec: yt_track.acodec,
            audio_channels: yt_track.audio_channels,
            duration: yt_track.duration,
        }
    }
}

#[derive(Deserialize, Serialize, Clone)]
pub struct Track {
    pub id: String,
    pub name: String,

    pub album_id: String,
    pub artist_ids: Vec<String>,

    pub audio_features: Option<AudioFeatures>,
    pub playback_data: PlaybackData,
}
