use serde::{Serialize, Deserialize};

#[derive(Deserialize, Serialize, Clone)]
pub struct Artist {
	pub genres: Option<Vec<String>>,
	pub href: String,
	pub id: String,
	pub name: String,
	pub popularity: Option<i32>,
	pub r#type: String,
}

#[derive(Deserialize, Serialize, Clone)]
pub struct Album {
	pub album_type: String,
	pub href: String,
	pub id: String,
	pub name: String,
	pub release_date: String,
	pub release_date_precision: String,
	pub total_tracks: i32,
	pub r#type: String,
}

#[derive(Deserialize, Serialize, Clone)]
pub struct Track {
	pub album: Album,
	pub artists: Vec<Artist>,
	pub disc_number: i32,
	pub duration_ms: i32,
	pub explicit: bool,
	pub href: String,
	pub id: String,
	pub is_local: bool,
	pub name: String,
	pub popularity: i32,
	pub preview_url: Option<String>,
	pub track_number: i32,
	#[serde(rename = "type")]
	pub track_type: String,
}