const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PlaybackDataSchema = new Schema({
    bit_rate: Number,
    sample_rate: Number,
    codec: String,
    audio_channels: Number,
    duration: Number,
});

const AudioFeaturesSchema = new Schema({
	acousticness: Number,
	danceability: Number,
	duration_ms: Number,
	energy: Number,
	instrumentalness: Number,
	key: Number,
	liveness: Number,
	loudness: Number,
	mode: Number,
	speechiness: Number,
	tempo: Number,
	time_signature: Number,
	valence: Number,
});

const trackSchema = new Schema({
    id: String,
    name: String,

    album_id: String,
    artist_ids: [String],

    audio_features: AudioFeaturesSchema,
    playback_data: PlaybackDataSchema,
});
module.exports = {
	Track: mongoose.model('Track', trackSchema),
	AudioFeatures: mongoose.model('AudioFeatures', AudioFeaturesSchema),
	PlaybackData: mongoose.model('PlaybackData', PlaybackDataSchema),
};