use serde::{Serialize, Deserialize};

#[derive(Deserialize, Serialize, Clone)]
pub struct Track {
	pub abr: f32, // audio bitrate
	pub acodec: String, // audio codec
	pub album: Option<String>, // album
	pub alt_title: Option<String>, // alternative title
	pub artist: Option<String>, // artist
	pub asr: u32, // audio sample rate
	// TODO: Check if we can use u32 instead of i32

	pub audio_channels: u32, // audio channels
	pub channel: String, // channel name
	pub creator: Option<String>, // creator
	pub duration: u32, // duration in seconds
	pub id: String, // video id
	pub release_year: Option<i32>, // release year
	pub tags: Vec<String>, // tags
	pub title: String, // video title
	pub track: Option<String>, // track
	pub upload_date: String, // upload date
}

// TODO: replace eyre with custom error type
pub async fn get_metadata(url: &str) -> Result<Track, eyre::Error> {
    let client = reqwest::Client::new();
    let text_response = client.get("http://localhost:5050/metadata")
    .query(&[("url", url)])
    .send()
    .await?
    .text()
    .await?;

    let metadata: Track = serde_json::from_str(text_response.as_str())?;

    Ok(metadata)
}

pub fn search_params_from_youtube_track(youtube_metadata: &Track) -> String {
    let mut parameters: Vec<String> = Vec::new();

    parameters.push(youtube_metadata.title.clone());

    if let Some(album) = youtube_metadata.album.clone() {
        parameters.push(format!("album: {}", album));
    }
    if let Some(track) = youtube_metadata.track.clone() {
        parameters.push(format!("track: {}", track));
    }
    if let Some(artist) = youtube_metadata.creator.clone() {
        parameters.push(format!("artist: {}", artist));
    }
    parameters.join(" ")
}
