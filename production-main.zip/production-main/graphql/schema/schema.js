const graphql = require('graphql');

const Album = require('../models/album');
const Artist = require('../models/artist');
const Track = require('../models/track');

const {
	GraphQLObjectType,
	GraphQLString,
	GraphQLID,
	GraphQLInt,
	GraphQLFloat,
	GraphQLBoolean,
	GraphQLSchema,
	GraphQLList
} = graphql;


const ArtistType = new GraphQLObjectType({
	name: 'Artist',
	fields: () => ({
		id: { type: GraphQLString },
		name: { type: GraphQLString },
		genres: { type: new GraphQLList(GraphQLString) },
	})
});

const AlbumType = new GraphQLObjectType({
	name: 'Album',
	fields: () => ({
		id: { type: GraphQLString },
		name: { type: GraphQLString },
	})
});


const PlaybackDataType = new GraphQLObjectType({
	name: 'PlaybackData',
	fields: () => ({
		bit_rate: { type: GraphQLFloat },
		sample_rate: { type: GraphQLInt },
		codec: { type: GraphQLString },
		audio_channels: { type: GraphQLInt },
		duration: { type: GraphQLInt },
	})
});

const AudioFeaturesType = new GraphQLObjectType({
	name: 'AudioFeatures',
	fields: () => ({
		acousticness: { type: GraphQLFloat },
		danceability: { type: GraphQLFloat },
		duration_ms: { type: GraphQLInt },
		energy: { type: GraphQLFloat },
		instrumentalness: { type: GraphQLFloat },
		key: { type: GraphQLInt },
		liveness: { type: GraphQLFloat },
		loudness: { type: GraphQLFloat },
		mode: { type: GraphQLInt },
		speechiness: { type: GraphQLFloat },
		tempo: { type: GraphQLFloat },
		time_signature: { type: GraphQLInt },
		valence: { type: GraphQLFloat },
	})
});

const TrackType = new GraphQLObjectType({
	name: 'Track',
	fields: () => ({
		id: { type: GraphQLString },
		name: { type: GraphQLString },
		audio_features: { type: AudioFeaturesType },
		playback_data: { type: PlaybackDataType },
		album: {
			type: AlbumType,
			resolve(parent) {
				return Album.findOne({id: parent.album_id});
			}
		},
		artists: {
			type: new GraphQLList(ArtistType),
			resolve(parent) {
				return Array.from(parent.artist_ids.map(artist_id => Artist.findOne({id: artist_id})));
			}
		},
	})
});

//RootQuery describes how users can use the graph and grab data.
//E.g Root query to get all authors, get all books, get a particular
//book or get a particular author.
const RootQuery = new GraphQLObjectType({
	name: 'RootQueryType',
	fields: {
		track: {
			type: TrackType,
			args: { id: { type: GraphQLID } },
			resolve(_, args) {
				return Track.find({id: args.id});
			}
		},
		tracks: {
			type: new GraphQLList(TrackType),
			resolve() {
				return Track.find({});
			}
		},
		artist: {
			type: ArtistType,
			args: { id: { type: GraphQLID } },
			resolve(_, args) {
				return Artist.find({id: args.id});
			}
		},
		artists: {
			type: new GraphQLList(ArtistType),
			resolve() {
				return Artist.find({});
			}
		},
		album: {
			type: AlbumType,
			args: { id: { type: GraphQLID } },
			resolve(_, args) {
				return Album.find({id: args.id});
			}
		},
		albums: {
			type: new GraphQLList(AlbumType),
			resolve() {
				return Album.find({});
			}
		}
	}
});

//Creating a new GraphQL Schema, with options query which defines query
//we will allow users to use it when they are making requestsuntil.
module.exports = new GraphQLSchema({
	query: RootQuery
});

